import React, { useEffect, useState } from "react";
import { getAllPosts } from "../Services/Api.js";

const Posts = () => {
  const [posts, setPosts] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = async () => {
    try {
      const data = await getAllPosts();
      console.log("Posts loaded:", data);
      setPosts(data);
    } catch (err) {
      setError("Failed to load posts");
      console.error(err);
    }
  };

  return (
    <div className="container mt-4">
      <h2>All Posts</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}

      {posts.length > 0 ? (
        posts.map((post) => (
          <div key={post.postId} className="card mt-3 p-3">
            <h5>{post.title}</h5>
            <p>{post.content}</p>
            <small>
              <b>Category:</b> {post.category.categoryTitle} <br />
              <b>Author:</b> {post.user.name}
            </small>
          </div>
        ))
      ) : (
        !error && <p>Loading posts...</p>
      )}
    </div>
  );
};

export default Posts;
