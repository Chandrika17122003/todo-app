import axios from "axios";

const BASE_URL = "http://localhost:9090/api/";

export const getAllPosts = async () => {
  try {
    const response = await axios.get(`${BASE_URL}posts/posts`);
    return response.data.content;  // since backend returns data inside "content"
  } catch (error) {
    console.error("Error fetching posts:", error);
    throw error;
  }
};
