import React, { useEffect, useState } from "react";
import { getAllUsers } from "../Services/Api.js";

export default function UsersPage() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let mounted = true;
    getAllUsers()
      .then((data) => { if (mounted) setUsers(data); })
      .catch((err) => { console.error(err); setError("Failed to load users"); })
      .finally(() => mounted && setLoading(false));
    return () => { mounted = false; };
  }, []);

  if (loading) return <div>Loading users...</div>;
  if (error) return <div style={{ color: "red" }}>{error}</div>;

  return (
    <div>
      <h2>Users</h2>
      {users.length === 0 ? (
        <div>No users found</div>
      ) : (
        <ul style={{ paddingLeft: 0, listStyle: "none" }}>
          {users.map(u => (
            <li key={u.userId ?? u.id} style={{ border: "1px solid #ddd", padding: 10, marginBottom: 8 }}>
              <strong>{u.name ?? u.username}</strong><br/>
              <small>{u.email}</small>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
