import React, { useEffect, useState } from "react";
import { getAllPosts } from "../Services/Api.js";

export default function PostsPage() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let mounted = true;
    getAllPosts()
      .then((data) => {
        if (!mounted) return;
        setPosts(data);
      })
      .catch((err) => {
        console.error(err);
        setError("Failed to load posts");
      })
      .finally(() => mounted && setLoading(false));

    return () => { mounted = false; };
  }, []);

  if (loading) return <div>Loading posts...</div>;
  if (error) return <div style={{ color: "red" }}>{error}</div>;

  return (
    <div>
      <h2>All Posts</h2>
      {posts.length === 0 ? (
        <div>No posts yet</div>
      ) : (
        <ul style={{ paddingLeft: 0, listStyle: "none" }}>
          {posts.map((p) => (
            <li key={p.postId ?? p.id} style={{ border: "1px solid #ddd", padding: 12, marginBottom: 8 }}>
              <h3 style={{ margin: "0 0 8px 0" }}>{p.title}</h3>
              <p style={{ margin: 0 }}>{p.content ?? p.body ?? "No content"}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
