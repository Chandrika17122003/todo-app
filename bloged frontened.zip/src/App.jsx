import React from "react";
import Posts from "./Components/Posts.jsx";

function App() {
  return (
    <div>
      <h1>Blog Frontend</h1>
      <Posts />
    </div>
  );
}

export default App;
